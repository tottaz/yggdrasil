<?

$conn = mysql_connect("localhost","username","password");
mysql_select_db("yourDbName",$conn);

?>