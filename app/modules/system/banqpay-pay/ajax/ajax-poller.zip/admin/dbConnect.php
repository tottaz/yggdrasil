<?

$conn = mysql_connect("host","username","password");
mysql_select_db("dbName",$conn);

?>