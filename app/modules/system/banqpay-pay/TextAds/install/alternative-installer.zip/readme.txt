If you have any trouble running the installer, try decompressing the alternative-install folder
into /install/