<?php

include '../config.php';

mysql_query ("
CREATE TABLE IF NOT EXISTS ADPACKAGES (
  `ID` int(6) NOT NULL auto_increment,
  `IMPRESSIONS` varchar(255) NOT NULL default '',
  `COST` varchar(255) NOT NULL default '',
  `NAME` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
")  or die (mysql_error());

mysql_query ("
CREATE TABLE IF NOT EXISTS `ADS` (
  `ID` int(6) NOT NULL auto_increment,
  `TITLE` varchar(255) NOT NULL default '',
  `DESCC` text NOT NULL,
  `URL` varchar(255) NOT NULL default '',
  `DISPURL` varchar(255) NOT NULL default '',
  `IMPRESSIONS` varchar(10) NOT NULL default '',
  `MAXIMPRESSIONS` varchar(255) NOT NULL default '',
  `CLICKS` varchar(10) NOT NULL default '',
  `CLIENT` varchar(255) NOT NULL default '',
  `STATUS` varchar(10) NOT NULL default '',
  `NAME` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
")  or die (mysql_error());

mysql_query ("
CREATE TABLE IF NOT EXISTS`CLIENTS` (
  `ID` int(6) NOT NULL auto_increment,
  `USERNAME` varchar(255) NOT NULL default '',
  `EMAIL` varchar(255) NOT NULL default '',
  `PASSWORD` varchar(255) NOT NULL default '',
  `IP` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
")  or die (mysql_error());

mysql_query ("
CREATE TABLE IF NOT EXISTS`PREFERENCES` (
  `ID` int(6) NOT NULL auto_increment,
  `MAXADS` char(4) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
")  or die (mysql_error());

mysql_query ("
CREATE TABLE IF NOT EXISTS`SETTINGS` (
  `USERNAME` varchar(255) NOT NULL default '',
  `PASSWORD` varchar(255) NOT NULL default '',
  `IP` varchar(255) NOT NULL default '',
  `PATH` varchar(255) NOT NULL default '',
  `ID` int(6) NOT NULL auto_increment,
  `RECEIVER_EMAIL` varchar(255) NOT NULL default '',
  `CURRENCY` varchar(20) NOT NULL default '',
  `LOGO_URL` varchar(255) NOT NULL default '',
  `SUCCESS_URL` varchar(255) NOT NULL default '',
  `CANCEL_URL` varchar(255) NOT NULL default '',
  `MAXADS` char(2) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;
")  or die (mysql_error());

$sql = "INSERT INTO SETTINGS SET USERNAME ='$aun', PASSWORD='$apw'";
$query = mysql_query($sql) or die("Cannot query the database.<br>" . mysql_error());

?>

<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
//-->
</script>
</head>

<body bgcolor="#FFFFFF" text="#000000" onLoad="MM_goToURL('parent','../admin/');return document.MM_returnValue">
</body>
</html>
