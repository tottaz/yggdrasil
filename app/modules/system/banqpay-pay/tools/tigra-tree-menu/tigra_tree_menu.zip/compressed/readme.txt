Use tree.js file from this directory instead of
that provided in the demos if you wish to speed
up site download and reduce network traffic
consumption.

Regular version of tree.js: ~5KB
Compressed version of menu.js: ~3KB

Don't remove product information block from tree.js
This is not allowed. If you modified the script or
if you wish to add your comments then put them after
product information block.
