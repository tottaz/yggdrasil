<?php
define('PHP_HTTP_TOOLS_INCLUDE_PATH', (dirname(__FILE__) . "/"));
require_once(PHP_HTTP_TOOLS_INCLUDE_PATH . 'php_http_client_generic.php');
?>