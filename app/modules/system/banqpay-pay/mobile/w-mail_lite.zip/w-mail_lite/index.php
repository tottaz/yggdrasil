<?php
/*
#######################################################################
# W-mail lite
#      - version 3.2.3
#      - Copyright (c) 2002-2003 Dominion Web Design
#      - http://www.dominion-web.com/products/w-mail/
#######################################################################
#
#        THIS SOFTWARE IS FREEWARE
#        Redistribution is permitted so long as the copyright notices
#        stay intact in the code and in the WML output
#
#######################################################################
*/
require ("./classes.php");

if ($_GET['do'] == "logout") {
	session_start(); 
	session_unset();
	session_destroy(); 
}

$MainSettings = new GlobalInit();

include ("./vars.php");

$OutputWML = new SetWML();

echo ("<wml>
<head>\n");

$OutputWML->SetHead();

echo ("</head>\n");

$OutputWML->SetCard();
?>
<do type="accept" label="Login">
<go href="menu.php" method="get">
<postfield name="u" value="$(u:noesc)"/>
<postfield name="p" value="$(p:noesc)"/>
</go>
</do>
<p><img src="w-mail.wbmp" alt="W-mail"/></p>
<p>Email address: <input type="text" name="u"/></p>
<p>Password:
<input type="password" name="p"/></p>
<p>
<anchor>Login
<go href="menu.php" method="get">
<postfield name="u" value="$(u:noesc)"/>
<postfield name="p" value="$(p:noesc)"/>
</go>
</anchor>
</p>
<p><br/>W-mail lite - v<? echo $version; ?><br/>
(c) 2003</p>
</card>
</wml>
