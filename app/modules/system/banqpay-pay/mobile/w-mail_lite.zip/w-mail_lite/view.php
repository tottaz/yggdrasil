<?php
/*
#######################################################################
# W-mail lite
#      - version 3.2.3
#      - Copyright (c) 2002-2003 Dominion Web Design
#      - http://www.dominion-web.com/products/w-mail/
#######################################################################
#
#        THIS SOFTWARE IS FREEWARE
#        Redistribution is permitted so long as the copyright notices
#        stay intact in the code and in the WML output
#
#######################################################################
*/
require ("./classes.php");

$MainSettings = new GlobalInit();

session_start();
$u = $_SESSION['sess_u'];
$p = $_SESSION['sess_p'];
$WAPimapserver = "";

$TransIDEnabled = $MainSettings->INIGet('session.use_trans_sid');

if ($_GET['cont'] == "") {
	$cont = 0;
}
else {
	$cont = $_GET['cont'];
}
$id = $_GET['id'];

include ("./vars.php");

$IMAPConnection = new WM_IMAPConnection(
	$_SESSION,
	$servertype,
	$IMAPPort,
	$defaultIMAP,
	$WAPimapserver
	);

$OutputWML = new SetWML();

echo ("<wml>
<head>\n");

$OutputWML->SetHead();

echo ("</head>\n");

$OutputWML->SetCard();
$OutputWML->SetPrev();

$mailbox = $IMAPConnection->WM_IMAPConnect();
$IMAPConnection->WM_IMAPGetHeader($id);
$fromdetails = $IMAPConnection->WM_IMAPMsgFrom();

$subj = $IMAPConnection->WM_IMAPGetSubject();

$structure = $IMAPConnection->WM_IMAPGetStructure($id);
if (sizeof($structure->parts) >= 1) {
	$sections = parseBody($structure);
}

if (is_array($sections)) {
	for($x=0; $x<sizeof($sections); $x++) {
		if ($sections[$x]["type"] == "multipart/alternative" && $sections[$x]["disposition"] != "attachment") {
			$message["alternative"] = $IMAPConnection->WM_IMAPGetBody($id, $sections[$x]["pid"], $sections[$x]["subpart"]);
		}
		elseif ($sections[$x]["type"] == "text/html"  && $sections[$x]["disposition"] != "attachment") {
			$message["html"] = $IMAPConnection->WM_IMAPGetBody($id, $sections[$x]["pid"], $sections[$x]["subpart"]);
			$message["html"] = stripslashes(parseEncoding($message["html"], $sections[$x]["encoding"]));
		}
		elseif ($sections[$x]["type"] == "text/plain"  && $sections[$x]["disposition"] != "attachment") {
			$message["text"] = $IMAPConnection->WM_IMAPGetBody($id, $sections[$x]["pid"], $sections[$x]["subpart"]);
			$message["text"] = parseEncoding($message["text"], $sections[$x]["encoding"]);
			$message["text"] = stripslashes(trim($message["text"]));
		}

	}
	if (!isset($message["text"]) && isset($message["html"])) {
		$content = $message["html"];
	}
	else {
		$content = $message["text"];
	}
}
else {
	if (($structure->subtype == "HTML" || $structure->subtype == "ALTERNATIVE")) {
		$content = $IMAPConnection->WM_IMAPGetBody($id, -1, -1);
		$content = stripslashes(parseEncoding($content, $sections[$x]["encoding"]));
	}
	else {
		$content = $IMAPConnection->WM_IMAPGetBody($id, -1, -1);
		$content = parseEncoding($content, $sections[$x]["encoding"]);
		$content = (stripslashes(trim($content)));
	}
}

$content = str_replace("  "," ",$content);
$content = str_replace("<","&lt;",$content);
$content = str_replace(">","&gt;",$content);
$content = str_replace("$","$$",$content);
$content = htmlspecialchars($content);
$content = nl2br($content);

$cntLength = strlen($content);

if ($cont == 0 || $cont == "") {
	echo ("<p>$subj<br/>");
	echo $fromdetails['name'];
	echo ("<br/>------</p>");

	$msgcut = substr($content,$cont,500);
	$cont2 = $cont + 500;
}
else {
	$msgcut = substr($content,$cont,650);
	$cont2 = $cont + 650;
}

echo ("<p>" . $msgcut . "</p>\n");

if (strlen($content) > $cont2) { 
	$seton = 1;
} else { 
	$seton = 0;
}
if ($seton == 1) {
	echo ("<p align=\"left\"><a href=\"view.php?cont=$cont2&amp;id=$id");
	$MainSettings->SessAppend($TransIDEnabled, 0);
	echo ("\">Continued...</a></p>");
}

echo ("<p>------</p>\n");
$IMAPConnection->WM_IMAPClose();

$OutputWML->SetMenu();
echo ("</card>\n</wml>");
?>