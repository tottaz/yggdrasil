<?php
/*
#######################################################################
# W-mail lite
#      - version 3.2.3
#      - Copyright (c) 2002-2003 Dominion Web Design
#      - http://www.dominion-web.com/products/w-mail/
#######################################################################
#
#        THIS SOFTWARE IS FREEWARE
#        Redistribution is permitted so long as the copyright notices
#        stay intact in the code and in the WML output
#
#######################################################################
*/

class GlobalInit {
	var $_versioncheck;
	var $_sid_enabled;

	function GlobalInit() {
		ini_set ( "arg_separator.output", "&amp;");
		ini_set ( "session.use_cookies", 0);

		ini_set ( "url_rewriter.tags", "a=href,area=href,frame=src,input=src,form=fakeentry");

		$this->_sid_enabled = true;

		// If PHP version is below 4.2.0 --enable-trans-sid is not loaded by default
		// So we need to check both the version and whether session.use_trans_sid is
		// is actually a loaded function in the session extension
		$this->version_check("4.2.0");
		if ($this->_versioncheck == true) {
			$this->check_trans_sid();
		}
	}
	function INIGet($WhichSetting) {
		return ini_get($WhichSetting);
	}
	function SessAppend($TransIDEnabled, $querybegin) {

		if (($TransIDEnabled == 0) || ($this->_sid_enabled == false)) {
			if ($querybegin == 1) {
				$sessappendreturn = "?";
			}
			else {
				$sessappendreturn = "&amp;";
			}
			$sessappendreturn .= SID;
		}
		else {
			$sessappendreturn = "";
		}
		echo $sessappendreturn;
		$sessappendreturn = null;
	}

	function version_check($vercheck) {
		$minver = explode(".", $vercheck);
		$curver = explode(".", phpversion());

		$versionfailure = 0;
		if($curver[0] < $minver[0]) {
			$versionfailure = 1;
		}
		if ($curver[1] < $minver[1] && $versionfailure == 0) {
			$versionfailure = 1;
		}
		if ($curver[2] < $minver[2] && $versionfailure == 0) {
			$versionfailure = 1;
		}
		if ($versionfailure == 1) {
			$this->_versioncheck = true;
		}
		else {
			$this->_versioncheck = false;
		}
		return $this->_versioncheck;
	}

	// Function for to check session.use_trans_sid if PHP < 4.2.0
	function check_trans_sid() {
		ob_start();
		phpinfo(INFO_GENERAL);
		$val_phpinfo .= ob_get_contents();
		ob_end_clean();
		if (strstr($val_phpinfo, "--enable-trans-sid")) {
			$this->_sid_enabled = true;
		}
		else {
			$this->_sid_enabled = false;
		}
		return $this->_sid_enabled;
	}
}

class WM_IMAPConnection {
	var $_sessionvars;
	var $_servertype;
	var $_serverport;
	var $_mailbox;
	var $_n;
	var $_numberofmessages;
	var $_messagesperpage;
	var $_msgheader;

	function WM_IMAPConnection( $sessionvars, $servertype, $serverport, $defaultserver, $WAPimapserver) {
		$this->_sessionvars=$sessionvars;
		$this->_servertype=$servertype;
		$this->_serverport=$serverport;
		$this->_defaultserver=$defaultserver;
		$this->_WAPimapserver = $this->_defaultserver;
		return $this->_WAPimapserver;
	}

	function WM_IMAPConnect() {
		if ($this->_servertype == "pop3") {
			$this->_mailbox = @imap_open ("{" . $this->_WAPimapserver . ":" . $this->_serverport . "/pop3}INBOX", $this->_sessionvars['sess_u'], $this->_sessionvars['sess_p']);
		}
		else {
			$this->_mailbox = @imap_open ("{" . $this->_WAPimapserver . ":" . $this->_serverport . "}INBOX", $this->_sessionvars['sess_u'], $this->_sessionvars['sess_p']);
		}

		if ($this->_mailbox == FALSE) {
			$this->_mailboxerror = imap_errors();
		}

		return $this->_mailbox;
	}

	function WM_IMAPNumMessages() {
		$this->_numberofmessages = imap_num_msg($this->_mailbox);
		return $this->_numberofmessages;
	}

	function WM_IMAPNumMessages2() {
		$numberofmessages = imap_check($this->_mailbox);
		return $numberofmessages;
	}

	function WM_IMAPClose() {
		imap_close($this->_mailbox); 
	}

	function WM_IMAPGetHeader($msgid) {
		$this->_msgheader = imap_headerinfo($this->_mailbox,$msgid); 
	}

	function WM_IMAPMsgFrom() {
		$from = $this->_msgheader->from;
		foreach ($from as $id2 => $object) {
			$fromdetails['name'] = $object->personal;
			$fromdetails['address'] = $object->mailbox . "@" . $object->host;
		}
		return $fromdetails;
	}

	function WM_IMAPGetSubject() {
		$subj = $this->_msgheader->subject; 
		$subj = strip_tags($subj);
		$subj = trim($subj);
		$subj = str_replace("  "," ",$subj);
		$subj = str_replace("<","&lt;",$subj);
		$subj = str_replace(">","&gt;",$subj);
		$subj = str_replace("$","$$",$subj);
		$subj = htmlspecialchars($subj); 
		return $subj;
	}

	function WM_IMAPGetBody($msgid, $partid, $subpartid) {
		if ($partid >= 0) {
			if ($subpartid >= 0) {
				$content = imap_fetchbody($this->_mailbox, $msgid, $partid . "." . $subpartid);
			}
			else {
				$content = imap_fetchbody($this->_mailbox, $msgid, $partid);
			}
		}
		else {
			$content = imap_body($this->_mailbox, $msgid);
		}
		return $content;
	}

	function WM_IMAPGetStructure($msgid) {
		$this->_structure = imap_fetchstructure($this->_mailbox, $msgid);
		return $this->_structure;
	}

	function WM_IMAPList($n, $messagesperpage) {
		$this->_n=$n;
		$this->_messagesperpage=$messagesperpage;
		$sortmessages = imap_sort($this->_mailbox, SORTDATE, 1, SE_UID);
		if ($this->_n == '') {
			$uppermsg = $this->_numberofmessages;
			$lowermsg = $this->_numberofmessages - $this->_messagesperpage;
		}
		else {
			$uppermsg = $this->_n;
			$lowermsg = $this->_n - $this->_messagesperpage;
		}

		if ($lowermsg <= 1) {
			$lowermsg = 1;
		}

		$MainSettings = new GlobalInit();
		$TransIDEnabled = $MainSettings->INIGet('session.use_trans_sid');

		$overview = imap_fetch_overview($this->_mailbox,"$uppermsg:$lowermsg",0); 
		$size = sizeof($overview); 
		for ($i = $size-1; $i >= 0; $i--) { 
			$val = $overview[$i]; 
			$msg = $val->msgno; 
			$from = $val->from; 
			$date = $val->date; 
			$subj = $val->subject; 
			$subj = strip_tags($subj);
			$subj = trim($subj);
			$subj = str_replace("  "," ",$subj);
			$subj = str_replace("<","&lt;",$subj);
			$subj = str_replace(">","&gt;",$subj);
			$subj = htmlspecialchars($subj);
			$cutsubj = substr($subj, 0, 25);
			$cutsubj = htmlspecialchars(str_replace("$", "$$", $cutsubj)) . "...";
			echo ("<p>#$msg:<br/><a href=\"view.php?id=$msg");
			$MainSettings->SessAppend($TransIDEnabled, 0);
			echo ("\">$cutsubj</a></p>\n");
		}
		if ($lowermsg >= 2) {
			$next = $lowermsg - 1;
			echo("<p><a href=\"mailbox.php?n=$next");
			$MainSettings->SessAppend($TransIDEnabled, 0);
			echo ("\">Next</a></p>\n");
		}
	}
}

class SetWML {

	function SetWML() {
		header("Content-type: text/vnd.wap.wml");
		echo ("<?xml version=\"1.0\"?>\n");
		echo ("<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n");
	}
	function SetHead() {
		echo ("<meta forua=\"true\" http-equiv=\"Cache-Control\" content=\"max-age=0\"/>\n");
		echo ("<meta forua=\"true\" http-equiv=\"Cache-Control\" content=\"must-revalidate\"/>");
	}
	function SetCard() {
		echo ("<card title=\"W-mail lite\" id=\"WMail\" ordered=\"true\" newcontext=\"false\">");
	}
	function SetPrev() {
		echo ("<do type=\"prev\" label=\"Back\">\n");
		echo ("<prev/>\n");
		echo ("</do>\n");
	}
	function SetMenu() {
		$MainSettings = new GlobalInit();
		$TransIDEnabled = $MainSettings->INIGet('session.use_trans_sid');
		echo ("<p><a href=\"menu.php");
		$MainSettings->SessAppend($TransIDEnabled, 1);
		echo ("\">Menu</a><br/><a href=\"index.php?do=logout");
		$MainSettings->SessAppend($TransIDEnabled, 0);
		echo ("\">Exit</a></p>");
	}
	
}

$type = array("text", "multipart", "message", "application", "audio", "image", "video", "other");
$encoding = array("7bit", "8bit", "binary", "base64", "quoted-printable", "other");

function parseBody($structure) {
	global $type;
	global $encoding;

	$ret = array();

	$parts = $structure->parts;

	for($x=0; $x<sizeof($parts); $x++) {
		$ret[$x]["pid"] = ($x+1);

		$this = $parts[$x];

		if ($this->type == "") {
			$this->type = 0;
		}
		$ret[$x]["type"] = $type[$this->type] . "/" . strtolower($this->subtype);
// Partial begin to fix multipart/mixed which uses a sub part but cannot use imap_fetchbody()
		if ($ret[$x]["type"] == "multipart/alternative") {
			$reloop = $x;
		}

		if ($this->encoding == "") {
			$this->encoding = 0;
		}
		$ret[$x]["encoding"] = $encoding[$this->encoding];

		$ret[$x]["size"] = strtolower($this->bytes);

		$ret[$x]["disposition"] = strtolower($this->disposition);

		$ret[$x]["subpart"] = -1;

		if (strtolower($this->disposition) == "attachment") {
			$params = $this->dparameters;
			foreach ($params as $p) {
				if($p->attribute == "FILENAME")	{
					$ret[$x]["name"] = $p->value;
					break;
				}
			}
		}
	}

	// This extra loop is for multipart/mixed
	// multipart mixed is structured:
	// - multipart/alternative
	// - - text/plain
	// - - text/html
	// - attachments/type
	//
	// So we need to log where the multipart/alternative is
	// and reloop to get the content part ids

	if ($reloop >= 0) {
		$parts2 = $structure->parts[$reloop]->parts;
		for($i=0; $i<sizeof($parts2); $i++) {
			$ret[$x]["pid"] = ($reloop+1);
			$this = $parts2[$i];

			if ($this->type == "") {
				$this->type = 0;
			}
			$ret[$x]["type"] = $type[$this->type] . "/" . strtolower($this->subtype);

			if ($this->encoding == "") {
				$this->encoding = 0;
			}
			$ret[$x]["encoding"] = $encoding[$this->encoding];

			$ret[$x]["size"] = strtolower($this->bytes);

			$ret[$x]["disposition"] = strtolower($this->disposition);

			$ret[$x]["subpart"] = $i+1;

			if (strtolower($this->disposition) == "attachment") {
				$params = $this->dparameters;
				foreach ($params as $p) {
					if($p->attribute == "FILENAME")	{
						$ret[$x]["name"] = $p->value;
						break;
					}
				}
			}
			$x++;
		}
	}

	return $ret;
}

function parseEncoding($body, $encoding) {
	if ($encoding == "base64") {
		return imap_base64($body);
	}
	elseif ($encoding == "quoted-printable") {
		return imap_qprint($body);
	}
	else {
		return $body;
	}
}


?>
