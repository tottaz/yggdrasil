<?php
/*
#######################################################################
# W-mail lite
#      - version 3.2.3
#      - Copyright (c) 2002-2003 Dominion Web Design
#      - http://www.dominion-web.com/products/w-mail/
#######################################################################
#
#        THIS SOFTWARE IS FREEWARE
#        Redistribution is permitted so long as the copyright notices
#        stay intact in the code and in the WML output
#
#######################################################################
*/

// This is your default IMAP or POP3 server. 
// If the IMAP server is on this machine than you can use 'localhost'
$defaultIMAP = "localhost";

// Default port.
// Default for POP3 is 110 and for IMAP is 143
$IMAPPort = 143;

// Server type: 'pop3' or 'imap'
$servertype = "imap";

// How many messages to display per page (this is actually number -1).
// Remember you are limited by the mobile phone's maximum page size on Kb.
// Every phone is different in this respect
$messagesperpage = "4";

// Software version - Do not edit
$version = "3.2.3";
?>
