<?php
/*
#######################################################################
# W-mail lite
#      - version 3.2.3
#      - Copyright (c) 2002-2003 Dominion Web Design
#      - http://www.dominion-web.com/products/w-mail/
#######################################################################
#
#        THIS SOFTWARE IS FREEWARE
#        Redistribution is permitted so long as the copyright notices
#        stay intact in the code and in the WML output
#
#######################################################################
*/
require ("./classes.php");

$u = $_GET['u'];
$p = $_GET['p'];
$uex = explode("@", $u);
$u = $uex[0];
$domain = $uex[1];

require ("./vars.php");

$MainSettings = new GlobalInit();
$TransIDEnabled = $MainSettings->INIGet('session.use_trans_sid');

session_start();
if ((!isset($_SESSION['sess_u'])) && (!isset($_SESSION['sess_p']))) {
	$newlogin = 1;
	$_SESSION['sess_u'] = $u;
	$_SESSION['sess_p'] = $p;
	$newsession['sess_u'] = $u;
	$newsession['sess_p'] = $p;
}
else {
	$newsession = $_SESSION;
}

$IMAPConnection = new WM_IMAPConnection(
	$newsession,
	$servertype,
	$IMAPPort,
	$defaultIMAP,
	$WAPimapserver
	);

$OutputWML = new SetWML();

echo ("<wml>
<head>\n");

$OutputWML->SetHead();

echo ("</head>\n");

$OutputWML->SetCard();

$mailbox = $IMAPConnection->WM_IMAPConnect();

if (!$mailbox) {
	$servererrors = implode("<br/>\n", $IMAPConnection->_mailboxerror);
	if (strstr($servererrors, "invalid remote specification")) {
		$servererrors .= "<br/><br/>It's possible that this server does not support this protocol";
	}

	echo ("<p>\n");
	echo ("Error: Sorry your login failed.  Your server reported: $servererrors</p>\n");
	echo ("</card></wml>\n");
	exit;
}

$numberofmessages = $IMAPConnection->WM_IMAPNumMessages2();

echo ("<p>W-mail lite<br/></p>\n");
echo ("<p><a href=\"mailbox.php");
$MainSettings->SessAppend($TransIDEnabled, 1);
echo ("\">INBOX</a> " . $numberofmessages->Nmsgs . " (" . $numberofmessages->Recent . " new)</p>\n");
echo ("<p><a href=\"index.php?do=logout");
$MainSettings->SessAppend($TransIDEnabled, 0);
echo ("\">Exit</a></p>\n");

$IMAPConnection->WM_IMAPClose();

echo ("</card>\n</wml>");
?>