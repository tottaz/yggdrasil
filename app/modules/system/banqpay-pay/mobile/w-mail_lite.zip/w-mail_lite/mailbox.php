<?php
/*
#######################################################################
# W-mail lite
#      - version 3.2.3
#      - Copyright (c) 2002-2003 Dominion Web Design
#      - http://www.dominion-web.com/products/w-mail/
#######################################################################
#
#        THIS SOFTWARE IS FREEWARE
#        Redistribution is permitted so long as the copyright notices
#        stay intact in the code and in the WML output
#
#######################################################################
*/
require ("./classes.php");

$MainSettings = new GlobalInit();

session_start();
$u = $_SESSION['sess_u'];
$p = $_SESSION['sess_p'];
$WAPimapserver = "";

include ("./vars.php");

$IMAPConnection = new WM_IMAPConnection(
	$_SESSION,
	$servertype,
	$IMAPPort,
	$defaultIMAP,
	$WAPimapserver
	);

$OutputWML = new SetWML();

echo ("<wml>
<head>\n");

$OutputWML->SetHead();

echo ("</head>\n");

$OutputWML->SetCard();
$OutputWML->SetPrev();

$mailbox = $IMAPConnection->WM_IMAPConnect();
$numberofmessages = $IMAPConnection->WM_IMAPNumMessages();

echo ("<p>Inbox: " . $numberofmessages . " messages</p>\n");

$sortmessages = $IMAPConnection->WM_IMAPList($_GET['n'], $messagesperpage);

$IMAPConnection->WM_IMAPClose();

$OutputWML->SetMenu();
echo ("</card>\n</wml>");
?>