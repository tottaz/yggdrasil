<html>
<head>
<title>PHP Version Checker for W-mail</title>
</head>
<body>
<?php

echo ("<p><b>PHP Version</b>: " . phpversion());

function version_check($vercheck) {
	$minver = explode(".", $vercheck);
	$curver = explode(".", phpversion());
	$versionfailure = 0;
	if($curver[0] < $minver[0]) {
		$versionfailure = 1;
	}
	if ($curver[1] < $minver[1] && $versionfailure == 0) {
		$versionfailure = 1;
	}
	if ($curver[2] < $minver[2] && $versionfailure == 0) {
		$versionfailure = 1;
	}
	if ($versionfailure == 1) {
		echo (" - PHP 4.1.0 or greater is required</p>");
		$versioncheck = true;
	}
	else {
		echo (" - OK</p>");
		$versioncheck = false;
	}
	return $versioncheck;
}

function check_trans_sid() {
	ob_start();
	phpinfo(INFO_GENERAL);
	$val_phpinfo .= ob_get_contents();
	ob_end_clean();
	if (strstr($val_phpinfo, "--enable-trans-sid")) {
		$sid_enabled = true;
	}
	else {
		$sid_enabled = false;
	}
	return $sid_enabled;
}

$versioncheck = & version_check('4.1.0');

$sid_enabled = true;
if ($versioncheck == true) {
	$sid_enabled = & check_trans_sid();
}

$phpext = get_loaded_extensions();

echo ("<p><b>IMAP</b>: ");

if (in_array ("imap", $phpext)){
	echo (" Installed - OK");
} 
else {
	echo (" Not Installed");
}

echo ("<p><b>Session support</b>: ");

if (in_array ("session", $phpext)){
	echo (" Installed - OK");
} 
else {
	echo (" Not Installed");
}

$transidenabled = ini_get('session.use_trans_sid');

echo ("<p><b>Session trans_sid setting</b>: ");
if (($transidenabled == 0) || ($sid_enabled == false)) {
	echo (" Disabled - <font color=\"red\">DWmail should work with trans_sid disabled, however we advise that you enable it in your PHP settings if you can</font>");
}
else {
	echo (" Enabled - OK");
} 

?>
</body>
</html>