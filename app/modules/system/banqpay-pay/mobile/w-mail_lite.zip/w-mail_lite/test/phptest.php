<html>
<head>
<title>PHP Test Program for W-mail</title>
</head>
<body>
<!--
<?php
// is php running?
if (1==2) {
  echo "-->PHP is not currently installed - Please contact your system administrator.<!--";
}
else {
  echo "--".">";
}

echo "PHP is installed correctly";

echo "<"."!--";
?>
-->
</body>
</html>