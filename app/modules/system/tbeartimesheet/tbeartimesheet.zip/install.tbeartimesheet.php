<?php
/**
* @version 2010-12-03
* @package  TBEAR:TIMESHEET
* @file administrator/components/com_tbearjobs/uninstall.tbearjobs.php
* @copyright Copyright (C) 2010 ThunderBear Design. All rights reserved.
* @link http://www.thunderbeardesign.com
* @license    GNU/GPL
*/
	defined( '_JEXEC' ) or die( 'Restricted access' );
		function com_install()
		{
		?>
		<div class="header">
			Congratulations, TBEAR:TIMESHEET 1.0 successfully installed!
		</div>
		<?php
		}
?>