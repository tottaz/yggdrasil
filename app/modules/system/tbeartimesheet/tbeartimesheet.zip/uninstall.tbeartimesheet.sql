DROP TABLE IF EXISTS `#__tbeartimesheet_departments`;
DROP TABLE IF EXISTS `#__tbearfill_config`;
