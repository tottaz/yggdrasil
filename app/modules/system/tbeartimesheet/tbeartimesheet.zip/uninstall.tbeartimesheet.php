<?php
/**
* @version 2010-12-03
* @package  TBEAR:JOBS
* @file administrator/components/com_tbearjobs/uninstall.tbearjobs.php
* @copyright Copyright (C) 2010 ThunderBear Design. All rights reserved.
* @link http://www.thunderbeardesign.com
* @license    GNU/GPL
*/
	defined( '_JEXEC' ) or die( 'Restricted access' );
	function com_uninstall() 	{
		?>
		<div class="header">TBEAR:TIMESHEET Removed...</div>
		<p>
		Sorry to see you go...
		</p>
		<?php
	}
?>